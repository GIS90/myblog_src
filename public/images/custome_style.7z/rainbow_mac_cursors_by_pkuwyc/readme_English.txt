<===== Info =====>

Name: Rainbow "Mac" Cursors
Author: pkuwyc
Release Date: May 1st, 2006





<===== About Rainbow "Mac" Cursors =====>

Actually, I started this animated cursors pack in last August. Finally it's here today! lol

This full cursors pack based on the Mac cursors has 15 animated cursors (ANI's), each of which has 24 frames that are in 24 different colors.

How-to-use: just right click on the included install.inf file, and choose "install"; go to the "mouse" dialog in the control panel, and choose "Rainbow Mac" in the "pointer" tab. That's all!

Have Fun!!

NO MODIFICATIONS, PORT OR REDISTRIBUTION WITHOUT PERMISSION!!





<===== About Myself =====>

Contact with me via pkuwyc@gmail.com
Welcome to my MSN Space: http://spaces.msn.com/wangyinchao
and my Homepage @ DA: http://pkuwyc.deviantart.com
Some of my other works are released on: http://esnips.com/web/pkuwyc (in English) & http://pkuwyc.ys168.com (in Simplified-Chinese)